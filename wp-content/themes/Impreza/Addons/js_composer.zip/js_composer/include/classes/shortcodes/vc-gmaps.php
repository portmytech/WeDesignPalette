<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Gmaps
 */
class WPBakeryShortCode_Vc_Gmaps extends WPBakeryShortCode {
}
